package com.SlotBooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SlotBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
