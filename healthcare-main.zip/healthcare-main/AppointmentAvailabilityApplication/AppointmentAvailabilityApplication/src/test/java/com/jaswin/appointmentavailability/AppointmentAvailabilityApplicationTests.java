package com.jaswin.appointmentavailability;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentAvailabilityApplicationTests {

	@Test
	void contextLoads() {
	}

}
