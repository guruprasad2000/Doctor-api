package com.jaswin.appointmentavailability;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppointmentAvailabilityApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppointmentAvailabilityApplication.class, args);
	}

}
